import SwiftUI
import CoreData
import UIKit
import CoreLocation
import MapKit

struct FoursquareVenue: Codable {
    let name: String
    let location: FoursquareLocation
}

struct FoursquareLocation: Codable {
    let formattedAddress: [String]
}

class APIManager {
    static let shared = APIManager()
    private init() {}
    
    @State private var responseJSON: String = ""
    @State private var responseRes: String = ""

    func fetchRestaurantData(latitude: CLLocationDegrees, longitude: CLLocationDegrees, restaurantName: String, completion: @escaping (Result<FoursquareVenue?, Error>) -> Void) {
        var encodedRestaurantName = restaurantName
        if restaurantName.contains(" ") {
            encodedRestaurantName = restaurantName.replacingOccurrences(of: " ", with: "%20")
        }
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyyMMdd"
        let currentDate = dateFormatter.string(from: Date())
        
        let categoryId = "4d4b7105d754a06374d81259" // Food category ID

        let headers = [
          "accept": "application/json",
          "Authorization": "fsq3tjG9ct8HetH248WzR1oSPyxnfcwbf98zy3ONtfd/dYY="
        ]

        let request = NSMutableURLRequest(url: NSURL(string: "https://api.foursquare.com/v3/places/search?query=\(encodedRestaurantName)&ll=\(latitude)%2C\(longitude)&radius=50")! as URL,
                                                cachePolicy: .useProtocolCachePolicy,
                                            timeoutInterval: 10.0)
        print(request.url)
        request.httpMethod = "GET"
        request.allHTTPHeaderFields = headers

        print(request.url)
        
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if let error = error {
                print("Error: \(error)")
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("Status code: \(httpResponse.statusCode)")
            }
            
            if let data = data {
                let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            
                print("\(responseJSON ?? "Unkown")")
                
                var bruh = "\(responseJSON ?? "Unkown")"

                if bruh.contains("(") {
                    bruh = bruh.replacingOccurrences(of: "(", with: "[")
                }

                if bruh.contains(")") {
                    bruh = bruh.replacingOccurrences(of: ")", with: "]")
                }

//                if bruh.contains(";") {
//                    bruh = bruh.replacingOccurrences(of: ";", with: ",")
//                }

                print(bruh)
                
            }
        })

        dataTask.resume()

    }
}

struct RestaurantDetailView: View {
    @State var formattedAddress: String = ""
    @State var shortName: String = ""
    
    let restaurantName: String
    let latitude: CLLocationDegrees
    let longitude: CLLocationDegrees
    
    var body: some View {
        VStack {
            Text(restaurantName)
                .font(.largeTitle)
                .bold()
            
            Button("Get Restaurant Details", action: {
                APIManager.shared.fetchRestaurantData(latitude: latitude, longitude: longitude, restaurantName: restaurantName) { result in
                    switch result {
                    case .success(let venue):
                        if let venue = venue {
                            self.shortName = venue.name
                            self.formattedAddress = venue.location.formattedAddress.joined(separator: ", ")
                        }
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                }
            })
            
            Text("Restauraunt Name: \(restaurantName)")
                .font(.subheadline)
            Text("Latitude: \(latitude)")
                .font(.subheadline)
            Text("Longitude: \(longitude)")
                .font(.subheadline)
            Text("Type Of Restauraunt: \(shortName)")
                .font(.subheadline)
            Text("Address: \(formattedAddress)")
                .font(.subheadline)
            Spacer()
        }
        .padding()
    }
}

struct RestaurantDetailView_Previews: PreviewProvider {
    static var previews: some View {
        RestaurantDetailView(restaurantName: "Test Restaurant", latitude: 33.448253, longitude: -112.076617)
    }
}

