//
//  ClassProjectCSE335App.swift
//  ClassProjectCSE335
//
//  Created by Anish Kolan on 4/21/23.
//

import SwiftUI

@main
struct ClassProjectCSE335App: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView(locationDataManager: LocationDataManager())
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
