//
//  ContentView.swift
//  ClassProjectCSE335
//
//  Created by Anish Kolan on 4/21/23.
//

import MapKit
import SwiftUI
import CoreData

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @ObservedObject var locationDataManager : LocationDataManager

    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Meal.foodName, ascending: true)],
        animation: .default)
    var meals: FetchedResults<Meal>
    @State var toInsertView = false
    @State var mealName = ""

    var body: some View {
        NavigationView {
            VStack{
            Text("Choose Your Meal")
                .font(.title)
                List {
                    ForEach(meals) { meal in
                        NavigationLink {
                            RestaurantView(locationDataManager: LocationDataManager(), meal: meal)
                            //                        Text("Item at \(meal.foodName ?? "")")
                        } label: {
                            Text(meal.foodName!)
                        }
                    }
                    .onDelete(perform: deleteItems)
                }
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        EditButton()
                    }
                    ToolbarItem {
                        Button(action: {toInsertView = true}) {
                            Label("Add Item", systemImage: "plus")
                        }
                    }
                }
                .alert("Insert", isPresented: $toInsertView, actions: {
                    TextField("Add Meal", text: $mealName)
                    Button("Insert", action:{
                        addItem()
                    })
                    Button("Cancel", role: .cancel, action: {
                        toInsertView = false
                    })
                }, message: {
                    Text("Please Enter Your Requested Craving")
                })
            }
        }
    }

    private func addItem() {
        withAnimation {
            let newItem = Meal(context: viewContext)
            newItem.foodName = mealName
            newItem.id = UUID()
            do {
                try viewContext.save()
                print(mealName)
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }

    private func deleteItems(offsets: IndexSet) {
        withAnimation {
            offsets.map { meals[$0] }.forEach(viewContext.delete)

            do {
                try viewContext.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nsError = error as NSError
                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
            }
        }
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(locationDataManager: LocationDataManager()).environment(\.managedObjectContext, PersistenceController.preview.container.viewContext)
    }
}
