import SwiftUI
import CoreData
import UIKit
import CoreLocation
import MapKit

struct Location: Identifiable {
    let id = UUID()
    var name: String
    var coordinate: CLLocationCoordinate2D
}
struct RestaurantView: View {
    @ObservedObject var locationDataManager: LocationDataManager
    @State private var region =
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 33.448253, longitude: -112.076617),
            span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
        )
    @State private var markers = [Location]()
    let meal: Meal

    var body: some View {
        VStack {
            Text(meal.foodName ?? "")
                .font(.largeTitle)
                .bold()
            Map(
                coordinateRegion: $region,
                interactionModes: .all,
                showsUserLocation: true,
                userTrackingMode: .constant(.follow),
                annotationItems: markers
            ) { location in
                MapAnnotation(coordinate: location.coordinate) {
                    VStack(alignment: .center) {
                        Text(location.name)
                            .bold()
                            .foregroundColor(.white)
                            .padding(.horizontal, 4)
                            .background(Color.black.opacity(0.7))
                            .clipShape(RoundedRectangle(cornerRadius: 4))
                            .font(.system(size: 15))
                        Image(systemName: "mappin")
                            .resizable()
                            .foregroundColor(.red)
                            .frame(width: 12, height: 32, alignment: .center)
                    }
                }
            }
            .frame(height: 300)
            List(markers) { location in
                VStack(alignment: .leading) {
                    NavigationLink(destination: RestaurantDetailView(restaurantName: location.name, latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)) {
                        Text(location.name)
                            .font(.headline)
                        Text("(\(location.coordinate.latitude), \(location.coordinate.longitude))")
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                }
            }
        }
        
        .onAppear {
            if let currentLocation = locationDataManager.getCurrentLocation() {
                region = MKCoordinateRegion(center: currentLocation, span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2))
            }
        }
        searchNearbyRestaurants
        .navigationBarTitleDisplayMode(.inline)
    }

    private var searchNearbyRestaurants: some View {
        HStack{
            Button {
                let request = MKLocalSearch.Request()
                request.naturalLanguageQuery = meal.foodName
                request.region = region
                
                MKLocalSearch(request: request).start { response, error in
                    guard let response = response else {
                        print("Error: \(error?.localizedDescription ?? "Unkown error").")
                        return
                    }
                    region = response.boundingRegion
                    markers = response.mapItems.map { item in
                        Location(
                            name: item.name ?? "",
                            coordinate: item.placemark.coordinate
                        )
                    }
                }
                
            } label: {
                Image(systemName: "location.magnifyingglass")
                    .resizable()
                    .foregroundColor(.accentColor)
                    .frame(width: 24, height: 24)
                    .padding(.trailing, 12)
            }
        }
    }
}

struct RestaurantView_Previews: PreviewProvider {
    static var previews: some View {
        RestaurantView(locationDataManager: LocationDataManager(), meal: Meal())
    }
}

